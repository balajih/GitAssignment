export class ParentTask {
    constructor(public ParentID?: number, public ParentTask?:string){}
}
