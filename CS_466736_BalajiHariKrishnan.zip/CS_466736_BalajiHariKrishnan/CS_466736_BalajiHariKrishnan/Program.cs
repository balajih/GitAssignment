﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_466736_BalajiHariKrishnan
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = new CurrentAccount().OpenAccount(121231,"asdasd");
            var asss = new CurrentAccount().OpenAccount(12, "asdasd");
        }
    }
}
