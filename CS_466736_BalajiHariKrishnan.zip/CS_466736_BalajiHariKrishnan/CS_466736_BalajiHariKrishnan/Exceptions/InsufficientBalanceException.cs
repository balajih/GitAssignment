﻿using System;

namespace CS_466736_BalajiHariKrishnan.Exceptions
{
    /// <summary>
    /// InsufficientBalanceException
    /// </summary>
    public class InsufficientBalanceException : Exception
    {
        //ctor
        public InsufficientBalanceException(string message) : base(message)
        {
        }
    }
}
