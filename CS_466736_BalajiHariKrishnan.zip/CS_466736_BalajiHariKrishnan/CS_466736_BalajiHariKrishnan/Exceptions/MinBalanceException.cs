﻿using System;

namespace CS_466736_BalajiHariKrishnan.Exceptions
{
    /// <summary>
    /// MinBalanceException
    /// </summary>
    public class MinBalanceException : Exception
    {
        //ctor
        public MinBalanceException(string message) : base(message)
        {
        }
    }
}
