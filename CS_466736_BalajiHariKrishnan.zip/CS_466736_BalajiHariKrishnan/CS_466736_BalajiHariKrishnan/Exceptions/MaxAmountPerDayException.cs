﻿using System;

namespace CS_466736_BalajiHariKrishnan.Exceptions
{
    /// <summary>
    /// MaxAmountPerDayException
    /// </summary>
    public class MaxAmountPerDayException : Exception
    {
        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="message"></param>
        public MaxAmountPerDayException(string message) : base(message)
        {
        }
    }
}
