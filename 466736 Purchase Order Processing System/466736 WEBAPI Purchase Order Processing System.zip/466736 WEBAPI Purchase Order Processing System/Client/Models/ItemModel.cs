﻿namespace Client.Models
{
    public class ItemModel
    {
        public string Code { get; set; }
        public string Desc { get; set; }
        public decimal Rate { get; set; }
    }
}