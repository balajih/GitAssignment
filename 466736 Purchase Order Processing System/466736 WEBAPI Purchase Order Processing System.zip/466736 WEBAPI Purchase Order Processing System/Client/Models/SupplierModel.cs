﻿namespace Client.Models
{
    public class SupplierModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
    }
}