﻿namespace _466736_WEBAPI_Purchase_Order_Processing_System.Models
{
    public class ItemModel
    {
        public string Code { get; set; }
        public string Desc { get; set; }
        public decimal Rate { get; set; }
    }
}