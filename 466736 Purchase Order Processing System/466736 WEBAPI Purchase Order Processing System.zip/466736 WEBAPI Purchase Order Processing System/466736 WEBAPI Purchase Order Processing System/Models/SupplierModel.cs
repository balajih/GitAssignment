﻿namespace _466736_WEBAPI_Purchase_Order_Processing_System.Models
{
    public class SupplierModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
    }
}